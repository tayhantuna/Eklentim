// Sayfa yüklendiğinde en son seçilen rengi yükle
document.addEventListener("DOMContentLoaded", async () => {
  const storedColor = await chrome.storage.local.get("selectedColor");
  const colorPicker = document.getElementById("colorPicker");

  if (storedColor.selectedColor) {
    colorPicker.value = storedColor.selectedColor;
  }
});

// Renk uygulama düğmesine basıldığında
document.getElementById("applyColor").addEventListener("click", async () => {
  const color = document.getElementById("colorPicker").value;
  applyColorToPage(color);
  chrome.storage.local.set({ selectedColor: color });
});

// Geri Al düğmesine basıldığında önceki renge dön
document.getElementById("undoColor").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      if (window.previousBackgroundColor) {
        document.body.style.backgroundColor = window.previousBackgroundColor;
        window.previousBackgroundColor = null;
      }
    }
  });
});

// Varsayılan renge dön
document.getElementById("resetColor").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      document.body.style.backgroundColor = "";
    }
  });

  // Hafızayı temizle
  chrome.storage.local.remove("selectedColor");
});

// Renk paletinden bir renk seçildiğinde
document.querySelectorAll(".color-swatch").forEach(swatch => {
  swatch.addEventListener("click", () => {
    const color = swatch.getAttribute("data-color");
    document.getElementById("colorPicker").value = color;
    applyColorToPage(color);
    chrome.storage.local.set({ selectedColor: color });
  });
});

// Rengi uygulayan fonksiyon
async function applyColorToPage(color) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (color) => {
      if (!window.previousBackgroundColor) {
        window.previousBackgroundColor = document.body.style.backgroundColor;
      }
      document.body.style.backgroundColor = color;
    },
    args: [color]
  });
}
